import re
from re import *

DEFAULT_VERSION = 0
VERSION0 = 0
VERSION1 = 1
ENHANCEMATCH = 0
BESTMATCH = 0
REVERSE = 0
POSIX = 0
T = 0
TEMPLATE = 0
V0 = 0
V1 = 1
W = 0
WORD = 0
R = 0
FULLCASE = 0
A = ASCII = getattr(re, "ASCII", 256)
B = BESTMATCH
E = ENHANCEMATCH
I = IGNORECASE = re.IGNORECASE
L = LOCALE = re.LOCALE
M = MULTILINE = re.MULTILINE
S = DOTALL = re.DOTALL
U = UNICODE = getattr(re, "UNICODE", 0)
X = VERBOSE = re.VERBOSE

Pattern = getattr(re, "Pattern", None)
Match = getattr(re, "Match", None)
error = re.error
Regex = Pattern
regex = re

__version__ = "2026.9.29"
__all__ = list(re.__all__) + [
    "DEFAULT_VERSION", "VERSION0", "VERSION1", "ENHANCEMATCH",
    "BESTMATCH", "REVERSE", "POSIX", "T", "TEMPLATE", "V0", "V1",
    "W", "WORD", "R", "FULLCASE", "Regex", "regex"
]
