import os
import sys

# 1. SSL Certificates auto-configuration
try:
    import certifi
    cert_path = certifi.where()
    if cert_path and os.path.exists(cert_path):
        os.environ.setdefault("SSL_CERT_FILE", cert_path)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", cert_path)
        os.environ.setdefault("CURL_CA_BUNDLE", cert_path)
        try:
            import ssl
            ssl._create_default_https_context = lambda: ssl.create_default_context(cafile=cert_path)
        except Exception:
            pass
except Exception:
    pass

# 2. Safe PIL / Pillow ImageFont TrueType resolution on Android
try:
    import PIL.ImageFont as _ImageFont
    _orig_truetype = _ImageFont.truetype

    def _safe_truetype(font=None, size=10, index=0, encoding='', layout_engine=None, **kwargs):
        try:
            return _orig_truetype(font, size, index=index, encoding=encoding, layout_engine=layout_engine, **kwargs)
        except (OSError, IOError, Exception):
            is_bold = 'bold' in str(font).lower()
            system_candidates = [
                '/system/fonts/Roboto-Bold.ttf' if is_bold else '/system/fonts/Roboto-Regular.ttf',
                '/system/fonts/DroidSans-Bold.ttf' if is_bold else '/system/fonts/DroidSans.ttf',
                '/system/fonts/NotoSansCJK-Regular.ttc',
                '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if is_bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                'fonts/Roboto-Bold.ttf' if is_bold else 'fonts/Roboto-Regular.ttf',
                'fonts/arial.ttf'
            ]
            for cand in system_candidates:
                if os.path.exists(cand):
                    try:
                        return _orig_truetype(cand, size, index=index, encoding=encoding, layout_engine=layout_engine, **kwargs)
                    except Exception:
                        pass
            try:
                return _ImageFont.load_default(size=size)
            except Exception:
                return _ImageFont.load_default()

    _ImageFont.truetype = _safe_truetype
except Exception:
    pass

# 3. DBAPI context manager support
try:
    import pg8000.dbapi as dbapi
    if not hasattr(dbapi.Cursor, '__enter__'):
        dbapi.Cursor.__enter__ = lambda self: self
    if not hasattr(dbapi.Cursor, '__exit__'):
        def _c_exit(self, exc_type, exc_val, exc_tb):
            try:
                self.close()
            except Exception:
                pass
        dbapi.Cursor.__exit__ = _c_exit

    if not hasattr(dbapi.Connection, '__enter__'):
        dbapi.Connection.__enter__ = lambda self: self
    if not hasattr(dbapi.Connection, '__exit__'):
        def _conn_exit(self, exc_type, exc_val, exc_tb):
            if exc_type is not None:
                try:
                    self.rollback()
                except Exception:
                    pass
            else:
                try:
                    self.commit()
                except Exception:
                    pass
        dbapi.Connection.__exit__ = _conn_exit
except Exception:
    pass
