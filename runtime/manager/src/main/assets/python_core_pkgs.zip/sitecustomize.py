"""
Android runtime compatibility initialization for Python
"""
import sys
import threading

# Patch multiprocessing.synchronize / SemLock on Android if missing /dev/shm
try:
    import multiprocessing.synchronize
    import multiprocessing.context

    _orig_RLock = multiprocessing.context.BaseContext.RLock
    _orig_Lock = multiprocessing.context.BaseContext.Lock
    _orig_Value = multiprocessing.context.BaseContext.Value

    class _ThreadSafeValue:
        def __init__(self, typecode_or_type, *args, lock=None, ctx=None):
            self._val = args[0] if args else (0 if typecode_or_type in ('i', 'l', 'B', 'b', 'h', 'H', 'I', 'L') else 0.0)
            self._lock = threading.RLock()
        @property
        def value(self):
            with self._lock: return self._val
        @value.setter
        def value(self, v):
            with self._lock: self._val = v

    def _safe_Value(self, typecode_or_type, *args, lock=True, ctx=None):
        try:
            return _orig_Value(self, typecode_or_type, *args, lock=lock, ctx=ctx)
        except Exception:
            return _ThreadSafeValue(typecode_or_type, *args, lock=lock, ctx=ctx)

    multiprocessing.context.BaseContext.Value = _safe_Value
except Exception:
    pass
