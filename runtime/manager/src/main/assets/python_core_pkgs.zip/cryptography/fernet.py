import base64
import time
import os
import hmac
import hashlib
from Cryptodome.Cipher import AES

class InvalidToken(Exception):
    pass

class InvalidSignature(Exception):
    pass

class Fernet:
    def __init__(self, key):
        if isinstance(key, str):
            key = key.encode('utf-8')
        decoded = base64.urlsafe_b64decode(key)
        if len(decoded) != 32:
            raise ValueError('Fernet key must be 32 url-safe base64-encoded bytes.')
        self._signing_key = decoded[:16]
        self._encryption_key = decoded[16:]

    def encrypt(self, data):
        if isinstance(data, str):
            data = data.encode('utf-8')
        current_time = int(time.time()).to_bytes(8, 'big')
        iv = os.urandom(16)
        pad_len = 16 - (len(data) % 16)
        padded_data = data + bytes([pad_len] * pad_len)
        cipher = AES.new(self._encryption_key, AES.MODE_CBC, iv)
        ciphertext = cipher.encrypt(padded_data)
        basic_parts = bytes([0x80]) + current_time + iv + ciphertext
        h = hmac.new(self._signing_key, basic_parts, hashlib.sha256).digest()
        return base64.urlsafe_b64encode(basic_parts + h)

    def decrypt(self, token, ttl=None):
        if isinstance(token, str):
            token = token.encode('utf-8')
        try:
            data = base64.urlsafe_b64decode(token)
        except Exception:
            raise InvalidToken()
        if len(data) < 57 or data[0] != 0x80:
            raise InvalidToken()
        basic_parts = data[:-32]
        expected_hmac = data[-32:]
        h = hmac.new(self._signing_key, basic_parts, hashlib.sha256).digest()
        if not hmac.compare_digest(h, expected_hmac):
            raise InvalidSignature()
        timestamp = int.from_bytes(data[1:9], 'big')
        if ttl is not None and time.time() - timestamp > ttl:
            raise InvalidToken()
        iv = data[9:25]
        ciphertext = data[25:-32]
        cipher = AES.new(self._encryption_key, AES.MODE_CBC, iv)
        padded_plain = cipher.decrypt(ciphertext)
        pad_len = padded_plain[-1]
        return padded_plain[:-pad_len]
