class InvalidSignature(Exception):
    pass

class InvalidKey(Exception):
    pass

class UnsupportedAlgorithm(Exception):
    pass

class AlreadyFinalized(Exception):
    pass

class AlreadyUpdated(Exception):
    pass

class NotYetFinalized(Exception):
    pass
