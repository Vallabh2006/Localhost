import pg8000.dbapi as dbapi
import queue
import threading

Error = dbapi.Error
DatabaseError = dbapi.DatabaseError
DataError = dbapi.DataError
OperationalError = dbapi.OperationalError
IntegrityError = dbapi.IntegrityError
InternalError = dbapi.InternalError
ProgrammingError = dbapi.ProgrammingError
NotSupportedError = dbapi.NotSupportedError

# Monkey-patch pg8000 Cursor and Connection for context manager support
if not hasattr(dbapi.Cursor, '__enter__'):
    dbapi.Cursor.__enter__ = lambda self: self
if not hasattr(dbapi.Cursor, '__exit__'):
    def _cursor_exit(self, exc_type, exc_val, exc_tb):
        try:
            self.close()
        except Exception:
            pass
    dbapi.Cursor.__exit__ = _cursor_exit

if not hasattr(dbapi.Connection, '__enter__'):
    dbapi.Connection.__enter__ = lambda self: self
if not hasattr(dbapi.Connection, '__exit__'):
    def _conn_exit(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            try:
                self.rollback()
            except Exception:
                pass
        else:
            try:
                self.commit()
            except Exception:
                pass
    dbapi.Connection.__exit__ = _conn_exit

def connect(*args, **kwargs):
    if 'dbname' in kwargs and 'database' not in kwargs:
        kwargs['database'] = kwargs.pop('dbname')
    if 'port' in kwargs and kwargs['port'] is not None:
        try:
            kwargs['port'] = int(kwargs['port'])
        except Exception:
            kwargs.pop('port', None)
    if 'sslmode' in kwargs:
        kwargs.pop('sslmode')
    return dbapi.connect(*args, **kwargs)

class pool:
    class AbstractConnectionPool:
        def __init__(self, minconn, maxconn, *args, **kwargs):
            self.minconn = int(minconn)
            self.maxconn = int(maxconn)
            self.args = args
            self.kwargs = kwargs
            self.closed = False
            self._pool = queue.Queue(maxsize=self.maxconn)
            self._lock = threading.Lock()
            for _ in range(self.minconn):
                self._pool.put(self._create_conn())

        def _create_conn(self):
            return connect(*self.args, **self.kwargs)

        def getconn(self):
            if self.closed:
                raise DatabaseError("connection pool is closed")
            try:
                return self._pool.get_nowait()
            except queue.Empty:
                return self._create_conn()

        def putconn(self, conn, close=False):
            if self.closed or close:
                try:
                    conn.close()
                except Exception:
                    pass
                return
            try:
                self._pool.put_nowait(conn)
            except queue.Full:
                try:
                    conn.close()
                except Exception:
                    pass

        def closeall(self):
            self.closed = True
            while not self._pool.empty():
                try:
                    conn = self._pool.get_nowait()
                    conn.close()
                except Exception:
                    pass

    class SimpleConnectionPool(AbstractConnectionPool):
        pass

    class ThreadedConnectionPool(AbstractConnectionPool):
        pass
