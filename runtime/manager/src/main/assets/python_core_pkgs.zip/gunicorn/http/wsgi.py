#
# This file is part of gunicorn released under the MIT license.
# See the NOTICE for more information.

import io
import logging
import os
import re
import sys

from gunicorn.http.message import TOKEN_RE
from gunicorn.http.errors import ConfigurationProblem, InvalidHeader, InvalidHeaderName
from gunicorn import SERVER_SOFTWARE, SERVER
from gunicorn import util

# Send files in at most 1GB blocks as some operating systems can have problems
# with sending files in blocks over 2GB.
BLKSIZE = 0x3FFFFFFF

# RFC9110 5.5: field-vchar = VCHAR / obs-text
# RFC4234 B.1: VCHAR = 0x21-x07E = printable ASCII
HEADER_VALUE_RE = re.compile(r'[ \t\x21-\x7e\x80-\xff]*')

log = logging.getLogger(__name__)


class FileWrapper:

    def __init__(self, filelike, blksize=8192):
        self.filelike = filelike
        self.blksize = blksize
        if hasattr(filelike, 'close'):
            self.close = filelike.close

    def __getitem__(self, key):
        data = self.filelike.read(self.blksize)
        if data:
            return data
        raise IndexError

    def __iter__(self):
        return self

    def __next__(self):
        data = self.filelike.read(self.blksize)
        if data:
            return data
        raise StopIteration


class WSGIErrorsWrapper(io.RawIOBase):

    def __init__(self, cfg):
        # There is no public __init__ method for RawIOBase so
        # we don't need to call super() in the __init__ method.
        # pylint: disable=super-init-not-called
        errorlog = logging.getLogger("gunicorn.error")
        handlers = errorlog.handlers
        self.streams = []

        if cfg.errorlog == "-":
            self.streams.append(sys.stderr)
            handlers = handlers[1:]

        for h in handlers:
            if hasattr(h, "stream"):
                self.streams.append(h.stream)

    def write(self, data):
        for stream in self.streams:
            try:
                stream.write(data)
            except UnicodeError:
                stream.write(data.encode("UTF-8"))
            stream.flush()


def base_environ(cfg):
    return {
        "wsgi.errors": WSGIErrorsWrapper(cfg),
        "wsgi.version": (1, 0),
        "wsgi.multithread": False,
        "wsgi.multiprocess": (cfg.workers > 1),
        "wsgi.run_once": False,
        "wsgi.file_wrapper": FileWrapper,
        "wsgi.input_terminated": True,
        "SERVER_SOFTWARE": SERVER_SOFTWARE,
    }


def default_environ(req, sock, cfg):
    env = base_environ(cfg)
    env.update({
        "wsgi.input": req.body,
        "gunicorn.socket": sock,
        "REQUEST_METHOD": req.method,
        "QUERY_STRING": req.query,
        "RAW_URI": req.uri,
        "SERVER_PROTOCOL": "HTTP/%s" % ".".join([str(v) for v in req.version])
    })
    return env


def proxy_environ(req):
    info = req.proxy_protocol_info

    if not info:
        return {}

    return {
        "PROXY_PROTOCOL": info["proxy_protocol"],
        "REMOTE_ADDR": info["client_addr"],
        "REMOTE_PORT": str(info["client_port"]),
        "PROXY_ADDR": info["proxy_addr"],
        "PROXY_PORT": str(info["proxy_port"]),
    }


def _make_early_hints_callback(req, sock, resp):
    """Create a wsgi.early_hints callback for sending 103 Early Hints.

    This allows WSGI applications to send 103 Early Hints responses
    before the final response, enabling browsers to preload resources.

    Args:
        req: The request object
        sock: The socket to write to
        resp: The Response object to check if headers have been sent

    Returns:
        A callback function that accepts a list of (name, value) header tuples
        and sends a 103 Early Hints response.

    Note:
        - Early hints are only sent for HTTP/1.1 or later clients
        - HTTP/1.0 clients will silently ignore the callback
        - Multiple calls are allowed (sending multiple 103 responses)
        - Calls after response has started are silently ignored
    """
    def send_early_hints(headers):
        """Send 103 Early Hints response.

        Args:
            headers: List of (name, value) header tuples, typically Link headers
                     Example: [('Link', '</style.css>; rel=preload; as=style')]

        Raises:
            InvalidHeaderName: If a header name is not a valid HTTP token.
            InvalidHeader: If a header value contains invalid characters.
        """
        # Don't send after response has started - would break framing
        if resp.headers_sent:
            return

        # Don't send to HTTP/1.0 clients - they don't support 1xx responses
        if req.version < (1, 1):
            return

        # Build 103 response
        response = b"HTTP/1.1 103 Early Hints\r\n"
        for name, value in headers:
            if isinstance(name, bytes):
                name = name.decode('latin-1')
            if isinstance(value, bytes):
                value = value.decode('latin-1')

            # Validate header name and value using the same checks as
            # Response.process_headers — defense-in-depth against
            # HTTP response splitting via CRLF injection.
            if not TOKEN_RE.fullmatch(name):
                raise InvalidHeaderName('%r' % name)
            if not HEADER_VALUE_RE.fullmatch(value):
                # Pass only the name — the invalid value may contain
                # sensitive data that shouldn't cross security boundaries
                # via exception propagation (browsers/proxies may forward
                # it to untrusted parties).
                raise InvalidHeader('%r' % name)

            value = value.strip(" \t")
            response += f"{name}: {value}\r\n".encode('latin-1')
        response += b"\r\n"

        util.write(sock, response)

    return send_early_hints


def create(req, sock, client, server, cfg, response_class=None,
           response_args=()):
    """Build the (response, environ) pair for a request.

    ``response_class`` and ``response_args`` let a protocol supply its own
    writer: HTTP/2 passes HTTP2Response so the body is framed as HTTP/2
    instead of HTTP/1, while everything else here stays the same.
    """
    if response_class is None:
        response_class = Response
    resp = response_class(req, sock, cfg, *response_args)

    # set initial environ
    environ = default_environ(req, sock, cfg)

    # default variables
    host = None
    script_name = os.environ.get("SCRIPT_NAME", "")

    if req._expected_100_continue:
        sock.send(b"HTTP/1.1 100 Continue\r\n\r\n")
        # rfc9112: Expect MUST be forwarded if the request is forwarded
        # N.B. gunicorn just sends at most one - application might send another

    # add the headers to the environ
    for hdr_name, hdr_value in req.headers:
        if hdr_name == 'HOST':
            host = hdr_value
        elif hdr_name == "SCRIPT_NAME":
            script_name = hdr_value
        elif hdr_name == "CONTENT-TYPE":
            environ['CONTENT_TYPE'] = hdr_value
            continue
        elif hdr_name == "CONTENT-LENGTH":
            environ['CONTENT_LENGTH'] = hdr_value
            continue

        # do not change lightly, this is a common source of security problems
        # RFC9110 Section 17.10 discourages ambiguous or incomplete mappings
        key = 'HTTP_' + hdr_name.replace('-', '_')
        if key in environ:
            hdr_value = "%s,%s" % (environ[key], hdr_value)
        environ[key] = hdr_value

    # set the url scheme
    environ['wsgi.url_scheme'] = req.scheme

    # set the REMOTE_* keys in environ
    # authors should be aware that REMOTE_HOST and REMOTE_ADDR
    # may not qualify the remote addr:
    # http://www.ietf.org/rfc/rfc3875
    if isinstance(client, str):
        environ['REMOTE_ADDR'] = client
    elif isinstance(client, bytes):
        environ['REMOTE_ADDR'] = client.decode()
    else:
        environ['REMOTE_ADDR'] = client[0]
        environ['REMOTE_PORT'] = str(client[1])

    # handle the SERVER_*
    # Normally only the application should use the Host header but since the
    # WSGI spec doesn't support unix sockets, we are using it to create
    # viable SERVER_* if possible.
    if isinstance(server, str):
        server = server.split(":")
        if len(server) == 1:
            # unix socket
            if host:
                server = host.split(':')
                if len(server) == 1:
                    if req.scheme == "http":
                        server.append(80)
                    elif req.scheme == "https":
                        server.append(443)
                    else:
                        server.append('')
            else:
                # no host header given which means that we are not behind a
                # proxy, so append an empty port.
                server.append('')
    environ['SERVER_NAME'] = server[0]
    environ['SERVER_PORT'] = str(server[1])

    # set the path and script name
    path_info = req.path
    if script_name:
        if not path_info.startswith(script_name):
            raise ConfigurationProblem(
                "Request path %r does not start with SCRIPT_NAME %r" %
                (path_info, script_name))
        path_info = path_info[len(script_name):]
    environ['PATH_INFO'] = util.unquote_to_wsgi_str(path_info)
    environ['SCRIPT_NAME'] = script_name

    # override the environ with the correct remote and server address if
    # we are behind a proxy using the proxy protocol.
    environ.update(proxy_environ(req))

    # Add wsgi.early_hints callback for sending 103 Early Hints
    environ['wsgi.early_hints'] = _make_early_hints_callback(req, sock, resp)

    # Add HTTP/2 stream priority if available
    if hasattr(req, 'priority_weight'):
        environ['gunicorn.http2.priority_weight'] = req.priority_weight
        environ['gunicorn.http2.priority_depends_on'] = req.priority_depends_on

    return resp, environ


class Response:

    def __init__(self, req, sock, cfg):
        self.req = req
        self.sock = sock
        self.version = SERVER
        self.status = None
        self.chunked = False
        self.must_close = False
        self.headers = []
        self.headers_sent = False
        self.response_length = None
        self.sent = 0
        self.upgrade = False
        self.cfg = cfg
        self._omits_body = False
        self._omits_body_warned = False

    def force_close(self):
        self.must_close = True

    def should_close(self):
        if self.must_close or self.req.should_close():
            return True
        if self.response_length is not None or self.chunked:
            return False
        if self.req.method == 'HEAD':
            return False
        if self.status_code < 200 or self.status_code in (204, 304):
            return False
        return True

    def start_response(self, status, headers, exc_info=None):
        if exc_info:
            try:
                if self.status and self.headers_sent:
                    util.reraise(exc_info[0], exc_info[1], exc_info[2])
            finally:
                exc_info = None
        elif self.status is not None:
            raise AssertionError("Response headers already set!")

        self.status = status

        # get the status code from the response here so we can use it to check
        # the need for the connection header later without parsing the string
        # each time.
        try:
            self.status_code = int(self.status.split()[0])
        except ValueError:
            self.status_code = None

        self.process_headers(headers)
        self._omits_body = self._response_omits_body(
            self.req.method, self.status_code)
        if self._omits_body and self._response_forbids_content_length(
                self.status_code):
            self.headers = [
                (k, v) for k, v in self.headers if k.lower() != "content-length"
            ]
            self.response_length = None
        self.chunked = self.is_chunked()
        return self.write

    @staticmethod
    def _response_omits_body(method, status):
        # RFC 9110: HEAD requests and 1xx/204/304 responses MUST NOT carry
        # a body, regardless of what the application emits.
        return (
            method == "HEAD"
            or status in (204, 304)
            or (status is not None and 100 <= status < 200)
        )

    @staticmethod
    def _response_forbids_content_length(status):
        # RFC 9110 §6.4.2: a server MUST NOT send Content-Length on 1xx or
        # 204. HEAD MAY include the Content-Length the same GET would carry,
        # and 304 MAY include the Content-Length of the unconditional response.
        return status == 204 or (status is not None and 100 <= status < 200)

    def process_headers(self, headers):
        for name, value in headers:
            if not isinstance(name, str):
                raise TypeError('%r is not a string' % name)

            if not TOKEN_RE.fullmatch(name):
                raise InvalidHeaderName('%r' % name)

            if not isinstance(value, str):
                raise TypeError('%r is not a string' % value)

            if not HEADER_VALUE_RE.fullmatch(value):
                raise InvalidHeader('%r' % value)

            # RFC9110 5.5
            value = value.strip(" \t")
            lname = name.lower()
            if lname == "content-length":
                self.response_length = int(value)
            elif util.is_hoppish(name):
                if lname == "connection":
                    # handle websocket
                    if value.lower() == "upgrade":
                        self.upgrade = True
                elif lname == "upgrade":
                    if value.lower() == "websocket":
                        self.headers.append((name, value))

                # ignore hopbyhop headers
                continue
            self.headers.append((name, value))

    def is_chunked(self):
        # Only use chunked responses when the client is
        # speaking HTTP/1.1 or newer and there was
        # no Content-Length header set.
        if self.response_length is not None:
            return False
        elif self.req.version <= (1, 0):
            return False
        elif self._omits_body:
            # No body permitted (HEAD or 1xx/204/304), so no chunked framing.
            return False
        return True

    def default_headers(self):
        # set the connection header
        if self.upgrade:
            connection = "upgrade"
        elif self.should_close():
            connection = "close"
        else:
            connection = "keep-alive"

        headers = [
            "HTTP/%s.%s %s\r\n" % (self.req.version[0],
                                   self.req.version[1], self.status),
            "Server: %s\r\n" % self.version,
            "Date: %s\r\n" % util.http_date(),
            "Connection: %s\r\n" % connection
        ]
        if self.chunked:
            headers.append("Transfer-Encoding: chunked\r\n")
        return headers

    def send_headers(self):
        if self.headers_sent:
            return
        tosend = self.default_headers()
        tosend.extend(["%s: %s\r\n" % (k, v) for k, v in self.headers])

        header_str = "%s\r\n" % "".join(tosend)
        util.write(self.sock, util.to_bytestring(header_str, "latin-1"))
        self.headers_sent = True

    def write(self, arg):
        self.send_headers()
        if not isinstance(arg, bytes):
            raise TypeError('%r is not a byte' % arg)
        if self._omits_body:
            if arg and not self._omits_body_warned:
                log.warning(
                    "WSGI app sent body bytes on a no-body response "
                    "(method=%s status=%s); dropping per RFC 9110.",
                    self.req.method, self.status_code,
                )
                self._omits_body_warned = True
            return
        arglen = len(arg)
        tosend = arglen
        if self.response_length is not None:
            if self.sent >= self.response_length:
                # Never write more than self.response_length bytes
                return

            tosend = min(self.response_length - self.sent, tosend)
            if tosend < arglen:
                arg = arg[:tosend]

        # Sending an empty chunk signals the end of the
        # response and prematurely closes the response
        if self.chunked and tosend == 0:
            return

        self.sent += tosend
        self._emit_body(arg)

    def _emit_body(self, data):
        """Put body bytes on the wire.

        The one place body framing happens, so a subclass can frame it
        differently without reimplementing write()'s bookkeeping.
        """
        util.write(self.sock, data, self.chunked)

    def can_sendfile(self):
        return self.cfg.sendfile is not False

    def sendfile(self, respiter):
        if self.cfg.is_ssl or not self.can_sendfile():
            return False

        if not util.has_fileno(respiter.filelike):
            return False

        fileno = respiter.filelike.fileno()
        try:
            offset = os.lseek(fileno, 0, os.SEEK_CUR)
            if self.response_length is None:
                filesize = os.fstat(fileno).st_size
                nbytes = filesize - offset
            else:
                nbytes = self.response_length
        except (OSError, io.UnsupportedOperation):
            return False

        if self._omits_body:
            self.send_headers()
            # Only complain when there really are body bytes to drop, the
            # same way write() only warns for a non-empty argument.
            if nbytes > 0 and not self._omits_body_warned:
                log.warning(
                    "WSGI app sent body bytes on a no-body response "
                    "(method=%s status=%s); dropping per RFC 9110.",
                    self.req.method, self.status_code,
                )
                self._omits_body_warned = True
            return True

        self.send_headers()

        if self.is_chunked():
            chunk_size = "%X\r\n" % nbytes
            self.sock.sendall(chunk_size.encode('utf-8'))
        if nbytes > 0:
            self.sock.sendfile(respiter.filelike, offset=offset, count=nbytes)

        if self.is_chunked():
            self.sock.sendall(b"\r\n")

        os.lseek(fileno, offset, os.SEEK_SET)

        return True

    def write_file(self, respiter):
        if not self.sendfile(respiter):
            for item in respiter:
                self.write(item)

    def close(self):
        if not self.headers_sent:
            self.send_headers()
        if self.chunked:
            util.write_chunk(self.sock, b"")
