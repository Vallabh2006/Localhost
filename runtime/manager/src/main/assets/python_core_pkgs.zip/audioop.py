"""
Pure-Python fallback for audioop (removed in Python 3.13+)
"""
import struct

class error(Exception):
    pass

def mul(fragment, width, factor):
    if width == 1:
        fmt = f'{len(fragment)}b'
        samples = struct.unpack(fmt, fragment)
        res = [max(-128, min(127, int(s * factor))) for s in samples]
        return struct.pack(fmt, *res)
    elif width == 2:
        fmt = f'{len(fragment)//2}h'
        samples = struct.unpack(fmt, fragment)
        res = [max(-32768, min(32767, int(s * factor))) for s in samples]
        return struct.pack(fmt, *res)
    return fragment

def tomono(fragment, width, lfactor, rfactor):
    return fragment

def tostereo(fragment, width, lfactor, rfactor):
    return fragment

def lin2lin(fragment, width, newwidth):
    return fragment

def ratecv(fragment, width, nchannels, inrate, outrate, state, weightA=1, weightB=0):
    return (fragment, state)

def avg(fragment, width):
    return 0

def max(fragment, width):
    return 0

def minmax(fragment, width):
    return (0, 0)

def cross(fragment, width):
    return 0

def rms(fragment, width):
    return 0
